import { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Type, 
  Hash, 
  AlignLeft, 
  Clock, 
  Mic2, 
  Copy, 
  Trash2, 
  Sun, 
  Moon, 
  Target, 
  CheckCircle2, 
  TrendingUp, 
  Gauge,
  Twitter,
  Linkedin,
  Instagram,
  Youtube,
  Search,
  BookOpen,
  HelpCircle,
  Code
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as textUtils from './lib/text-processing';

// --- Components ---

const StatCard = ({ label, value, subValue, variant = 'default', delay = 0 }: any) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    className={`p-4 rounded-xl border transition-all ${
      variant === 'primary' 
        ? 'bg-primary/5 border-primary/20 ring-1 ring-primary/5' 
        : 'bg-surface border-border-main hover:border-slate-300 dark:hover:border-slate-700'
    }`}
  >
    <div className="flex flex-col">
      <span className="text-[0.65rem] font-bold text-text-sub uppercase tracking-[0.1em] mb-1">{label}</span>
      <div className="flex items-baseline gap-1.5">
        <span className={`font-mono font-bold leading-tight ${variant === 'primary' ? 'text-2xl text-primary' : 'text-xl text-text-main'}`}>
          {typeof value === 'number' ? value.toLocaleString() : value}
        </span>
        {subValue && <span className="text-[0.65rem] text-text-sub font-semibold">{subValue}</span>}
      </div>
      {label === "Avg Word Length" && value > 25 && (
        <span className="text-[0.6rem] text-warning font-bold mt-1.5 flex items-center gap-1">
          <Hash className="w-2.5 h-2.5" /> Long words detected
        </span>
      )}
    </div>
  </motion.div>
);

const PlatformLimit = ({ name, count, limit }: any) => {
  const ratio = count / limit;
  let colorClass = 'bg-green-50 text-success border-green-200 dark:bg-green-950/20 dark:border-green-900/50';
  
  if (ratio > 1) {
    colorClass = 'bg-red-50 text-warning border-red-200 dark:bg-red-950/20 dark:border-red-900/50';
  } else if (ratio >= 0.8) {
    colorClass = 'bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900/50';
  }

  return (
    <div className={`px-2 py-1.5 rounded text-[0.7rem] font-bold border transition-colors ${colorClass}`}>
      <span className="opacity-80 uppercase mr-1">{name}:</span>
      {count}/{limit} {ratio > 1 && <span className="ml-1">⚠</span>}
    </div>
  );
};

// --- App Component ---

export default function App() {
  const [text, setText] = useState(() => localStorage.getItem('wordflow-text') || '');
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('wordflow-theme') === 'dark');
  const [goalInput, setGoalInput] = useState(() => localStorage.getItem('wordflow-goal') || '');
  const [isGoalMode, setIsGoalMode] = useState(() => !!localStorage.getItem('wordflow-goal'));
  const [showCelebration, setShowCelebration] = useState(false);
  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  const goal = Number(goalInput) || 0;

  // --- Derived Stats ---
  const stats = useMemo(() => {
    const wordCount = textUtils.getWordCount(text);
    return {
      wordCount,
      charCount: textUtils.getCharCount(text, true),
      charCountNoSpaces: textUtils.getCharCount(text, false),
      sentenceCount: textUtils.getSentenceCount(text),
      paragraphCount: textUtils.getParagraphCount(text),
      readingTime: textUtils.getReadingTime(wordCount),
      speakingTime: textUtils.getSpeakingTime(wordCount),
      uniqueWords: textUtils.getUniqueWordsCount(text),
      avgWordLength: textUtils.getAverageWordLength(text),
      keywordDensity: textUtils.getKeywordDensity(text),
      readability: textUtils.calculateReadability(text),
    };
  }, [text]);

  const goalReached = isGoalMode && goal > 0 && stats.wordCount >= goal;

  // --- Effects ---

  useEffect(() => {
    localStorage.setItem('wordflow-text', text);
  }, [text]);

  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark');
      localStorage.setItem('wordflow-theme', 'dark');
    } else {
      document.body.classList.remove('dark');
      localStorage.setItem('wordflow-theme', 'light');
    }
  }, [darkMode]);

  useEffect(() => {
    if (isGoalMode && goal > 0) {
      localStorage.setItem('wordflow-goal', goalInput);
    } else {
      localStorage.removeItem('wordflow-goal');
    }
  }, [isGoalMode, goalInput]);

  useEffect(() => {
    if (goalReached && !showCelebration) {
      setShowCelebration(true);
      setTimeout(() => setShowCelebration(false), 3000);
    }
  }, [goalReached]);

  // --- Handlers ---

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
  };

  const handleClear = () => {
    if (confirm('Clear all text?')) {
      setText('');
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 flex flex-col">
      {/* --- Header --- */}
      <nav className="sticky top-0 z-50 bg-white dark:bg-slate-950 border-b border-border-main">
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M4 7V4h16v3M9 20h6M12 4v16"/></svg>
            <h1 className="text-lg font-extrabold tracking-tight text-primary">
              WordFlow
            </h1>
          </div>
          <div className="flex items-center gap-6">
            <span className="text-xs text-text-sub font-medium hidden sm:block italic">Auto-saved to local Storage</span>
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className="px-3 py-1.5 rounded-md border border-border-main text-xs font-bold hover:bg-surface transition-colors flex items-center gap-2"
            >
              {darkMode ? <><Sun className="w-3.5 h-3.5" /> Light</> : <><Moon className="w-3.5 h-3.5" /> Dark</>}
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-10 flex-1 flex flex-col gap-10">
            {/* --- Hero Section --- */}
            <section className="text-center space-y-4 max-w-3xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-4xl sm:text-5xl font-black text-text-main tracking-tight leading-[1.1]"
          >
            Professional Word Counter for <span className="text-primary italic">High-Impact</span> Writing.
          </motion.h1>
          <p className="text-text-sub text-sm sm:text-base font-medium max-w-2xl mx-auto">
            Instantly analyze word count, readability, and keyword density. Built for authors, SEO experts, and students who demand precision.
          </p>
          <div className="flex items-center justify-center gap-3 pt-2">
            <span className="px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-bold uppercase tracking-wider text-text-sub">Paste text below to start</span>
          </div>
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-8 items-start">
          {/* --- Editor Area --- */}
          <div className="flex flex-col gap-6 h-full min-h-0">
            
            {/* Primary Live Stats Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-1">
              <StatCard label="Total Words" value={stats.wordCount} variant="primary" delay={0.1} />
              <StatCard label="Characters" value={stats.charCount} variant="primary" delay={0.15} />
              <StatCard label="Reading Time" value={stats.readingTime} delay={0.2} />
              <StatCard label="Speaking Time" value={stats.speakingTime} delay={0.25} />
            </div>

            <div className="relative flex-1 min-h-[450px] group">
              <textarea
                ref={textAreaRef}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Start typing or paste your content here..."
                style={{
                  fontSize: '16px',
                  lineHeight: '1.8',
                  color: darkMode ? '#e6edf3' : '#1a1a1a',
                  backgroundColor: darkMode ? '#0d1117' : '#ffffff',
                  WebkitTextFillColor: darkMode ? '#e6edf3' : '#1a1a1a',
                  wordBreak: 'break-word',
                  overflowWrap: 'break-word',
                  whiteSpace: 'pre-wrap',
                }}
                className="w-full h-full p-8 bg-white dark:bg-[#0d1117] border border-border-main rounded-2xl shadow-[0_0_50px_-12px_rgba(0,0,0,0.05)] focus:border-primary/50 dark:focus:border-primary/30 transition-all outline-none resize-none font-sans placeholder:text-slate-300 dark:placeholder:text-slate-700"
              />
              
              <div className="absolute bottom-6 right-8 flex items-center gap-4">
                <AnimatePresence>
                  {text && (
                    <motion.button 
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      onClick={handleClear}
                      className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                      title="Clear text"
                    >
                      <Trash2 className="w-5 h-5" />
                    </motion.button>
                  )}
                </AnimatePresence>
                <button 
                  onClick={handleCopy}
                  className="flex items-center gap-2 px-5 py-2.5 bg-text-main text-white dark:bg-white dark:text-slate-900 rounded-lg text-sm font-bold shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  <Copy className="w-4 h-4" /> Copy Text
                </button>
              </div>
            </div>

          {/* --- Goal Mode --- */}
          <div className="bg-blue-50 dark:bg-blue-950/20 p-5 rounded-lg border border-blue-100 dark:border-blue-900/40 mt-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase tracking-wider">
                <Target className="w-4 h-4" />
                Goal: {isGoalMode && goal > 0 ? `${goal} Words` : 'Set a Word Count Goal'}
              </div>
              {isGoalMode && goal > 0 && <span className="text-primary font-bold text-sm">{Math.round(Math.min((stats.wordCount / goal) * 100, 100))}%</span>}
            </div>

            {isGoalMode ? (
              <div className="space-y-3">
                <div className="h-2 bg-blue-100 dark:bg-blue-900/50 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min((stats.wordCount / goal) * 100, 100)}%` }}
                    className="h-full bg-primary"
                  />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-text-sub font-medium">{Math.max(0, goal - stats.wordCount)} words to go</span>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      value={goalInput}
                      placeholder="Set goal..."
                      onChange={(e) => setGoalInput(e.target.value)}
                      className="w-24 px-2 py-1 bg-white dark:bg-slate-800 border border-blue-200 dark:border-blue-900 rounded-md text-xs font-bold outline-none"
                    />
                    <button onClick={() => { setIsGoalMode(false); setGoalInput(''); }} className="text-[10px] font-bold text-text-sub hover:text-red-500 uppercase">Disable</button>
                  </div>
                </div>
              </div>
            ) : (
              <button 
                onClick={() => setIsGoalMode(true)}
                className="px-3 py-1.5 bg-primary text-white text-xs font-bold rounded shadow-sm hover:brightness-110"
              >
                Start Track Progress
              </button>
            )}
          </div>
        </div>

        {/* --- Stats Sidebar --- */}
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3">
            <StatCard label="Sentences" value={stats.sentenceCount} />
            <StatCard label="Paragraphs" value={stats.paragraphCount} />
            <StatCard label="Unique Words" value={stats.uniqueWords} />
            <StatCard label="Avg Word Length" value={stats.avgWordLength} subValue="chars" />
            
            <motion.div className="bg-surface border border-border-main p-4 rounded-xl hover:shadow-sm transition-all col-span-2">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[0.65rem] font-bold text-text-sub uppercase tracking-wider">Readability Analysis</span>
                <BookOpen className="w-4 h-4 text-primary" />
              </div>
              
              {stats.wordCount < 10 ? (
                <div className="text-[0.7rem] text-text-sub font-medium italic bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-dashed border-slate-200 dark:border-slate-700">
                  Enter 10+ words to unlock writing depth metrics.
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-black text-text-main">{stats.readability.grade}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`w-2 h-2 rounded-full ${
                          stats.readability.level === 'Easy' ? 'bg-success' : stats.readability.level === 'Medium' ? 'bg-orange-500' : 'bg-warning'
                        }`} />
                        <span className="text-[0.7rem] font-extrabold uppercase text-text-sub tracking-tight">
                          {stats.readability.level} Understanding
                        </span>
                      </div>
                    </div>
                    <div className="text-4xl font-black text-primary/10 tracking-tighter">{stats.readability.score}</div>
                  </div>
                  
                  {/* Visual Progress Bar */}
                  <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${stats.readability.score}%` }}
                      className={`h-full ${
                        stats.readability.score > 60 ? 'bg-success' : stats.readability.score > 30 ? 'bg-orange-500' : 'bg-warning'
                      }`}
                    />
                  </div>
                </div>
              )}
            </motion.div>
          </div>

          <div className="p-4 border border-border-main rounded-lg">
            <div className="text-[0.75rem] font-bold text-text-sub uppercase tracking-wider mb-3">Platform Limits</div>
            <div className="flex flex-wrap gap-2">
              <PlatformLimit name="Twitter" count={stats.charCount} limit={280} />
              <PlatformLimit name="LinkedIn" count={stats.charCount} limit={3000} />
              <PlatformLimit name="Instagram" count={stats.charCount} limit={2200} />
              <PlatformLimit name="Meta Desc" count={stats.charCount} limit={160} />
            </div>
          </div>

          <div className="p-4 border-2 border-primary/20 rounded-xl bg-white dark:bg-slate-900 shadow-lg shadow-primary/5">
            <div className="flex justify-between items-center mb-5 pb-3 border-b border-border-main">
              <span className="text-[0.8rem] font-black text-text-main dark:text-white uppercase tracking-widest">Keyword Density</span>
              <span className="text-[10px] font-black text-white px-3 py-1 bg-primary rounded-full shadow-sm">Top 10</span>
            </div>
            
            {stats.wordCount < 20 ? (
              <div className="text-[0.75rem] text-text-main dark:text-slate-400 font-medium italic text-center py-6">Start writing to analyze keywords...</div>
            ) : (
              <div className="space-y-4">
                {stats.keywordDensity.slice(0, 10).map((item, idx) => (
                  <div key={idx} className="flex justify-between text-xs items-center group">
                    <span className="font-bold text-text-main dark:text-slate-100 min-w-[80px] truncate">{item.word}</span>
                    <div className="flex items-center gap-3 flex-1 justify-end">
                      <div className="flex-1 max-w-[80px] h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-border-main">
                        <div 
                          className="h-full bg-primary shadow-[0_0_8px_rgba(0,102,255,0.4)] transition-all duration-700" 
                          style={{ width: `${Math.min(item.percentage * 5, 100)}%` }} 
                        />
                      </div>
                      <div className="flex flex-col items-end min-w-[50px]">
                        <span className="text-text-main dark:text-white font-black text-[11px] leading-tight">
                          {item.count}
                        </span>
                        <span className="text-[9px] text-primary font-bold font-mono">
                          {item.percentage}%
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-between items-center p-3 border border-border-main rounded-lg">
            <span className="text-[0.75rem] font-bold text-text-sub uppercase tracking-wider">Unique Words</span>
            <span className="text-lg font-bold text-text-main">{stats.uniqueWords}</span>
          </div>
        </div>
      </div>
    </main>

        {/* --- SEO CONTENT SECTION --- */}
        <div id="resources" className="mt-16 border-t border-border-main py-20 bg-slate-50/50 dark:bg-slate-900/20 -mx-6 sm:-mx-8">
          <div className="max-w-5xl mx-auto px-6 grid grid-cols-1 md:grid-cols-12 gap-12">
            
            <div className="md:col-span-8 space-y-12">
              <section>
                <h2 className="text-2xl font-black text-text-main tracking-tight mb-6">Writing Mastery with WordFlow.</h2>
                <p className="text-slate-600 dark:text-slate-200 leading-relaxed text-sm lg:text-base">
                  WordFlow is more than a simple <strong>word count checker</strong>. It's a digital editor designed to help you hit precise <strong>word count online</strong> goals while maintaining high readability. From analyzing a <strong>character counter online</strong> result to calculating a <strong>readability score checker</strong> grade, we provide the metrics you need to succeed.
                </p>
                
                <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-8">
                  <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-border-main shadow-sm">
                    <h3 className="font-bold text-text-main mb-3 flex items-center gap-2">
                      <Search className="w-4 h-4 text-primary" /> Why use WordFlow?
                    </h3>
                    <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-2 leading-relaxed list-disc pl-4">
                      <li>Real-time <strong>keyword density checker free</strong> logic.</li>
                      <li>Advanced <strong>flesch reading ease calculator</strong> for clarity.</li>
                      <li>Dedicated <strong>word counter for instagram</strong> and social limits.</li>
                      <li>Private and secure — your text stays in your browser.</li>
                    </ul>
                  </div>
                  <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-border-main shadow-sm">
                    <h3 className="font-bold text-text-main mb-3 flex items-center gap-2">
                      <HelpCircle className="w-4 h-4 text-primary" /> How to use it?
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      Simply paste your text above. The dashboard will automatically update every metric. Use the <strong>Goal Mode</strong> to stay on track for your essays or articles.
                    </p>
                  </div>
                </div>
              </section>

              <div className="space-y-6">
                <h2 className="text-xl font-black text-text-main tracking-tight">Writing Insights.</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Use existing FAQ logic but styled differently */}
                  {[
                    { q: "How many words in a 5 minute speech?", a: "A 5-minute speech averages 650-750 words at 130-150 WPM." },
                    { q: "How many words is a 1-minute read?", a: "Standard reading speed is about 238 words per minute." },
                    { q: "What is the Twitter limit?", a: "280 characters for standard users, tracked in real-time above." },
                    { q: "What is ideal keyword density?", a: "Aim for 1-2% for SEO without being flagged as spam." }
                  ].map((item, i) => (
                    <div key={i} className="border-l-2 border-primary/20 pl-4 py-1">
                      <b className="block text-xs text-text-main mb-1 uppercase tracking-widest">{item.q}</b>
                      <p className="text-xs text-slate-600 dark:text-slate-300 leading-normal">{item.a}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <aside className="md:col-span-4 space-y-8">
              <div className="p-6 bg-primary dark:bg-primary/90 text-white rounded-2xl shadow-xl shadow-primary/10">
                <h4 className="font-black text-lg mb-2">AdSense Ready.</h4>
                <p className="text-xs opacity-90 leading-relaxed mb-4">
                  This tool follows all Google Publisher Policies. High-value content, mobile-friendly design, and fast loading.
                </p>
                <div className="h-40 bg-white/10 rounded-lg flex items-center justify-center border border-white/20 uppercase text-[10px] font-bold tracking-widest">
                  Sidebar Ad Slot
                </div>
              </div>
              
              <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-border-main">
                <h4 className="font-bold text-slate-800 dark:text-slate-100 mb-4">Quick Links</h4>
                <ul className="text-xs space-y-3 font-medium text-slate-500 dark:text-slate-400">
                   <li className="hover:text-primary transition-colors cursor-pointer">About WordFlow</li>
                   <li className="hover:text-primary transition-colors cursor-pointer">Readability Checker</li>
                   <li className="hover:text-primary transition-colors cursor-pointer">Grammar Analysis</li>
                   <li className="hover:text-primary transition-colors cursor-pointer">Contact Support</li>
                </ul>
              </div>
            </aside>
          </div>
        </div>

        <div className="ad-slot text-[10px] h-14 bg-white dark:bg-slate-950 border border-dashed border-slate-300 dark:border-slate-800 flex items-center justify-center text-slate-400 uppercase tracking-widest font-bold mt-12 mb-4">
          Advertisement - Leaderboard
        </div>

      <footer className="mt-20 border-t border-slate-200 dark:border-slate-800 py-12 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col items-center md:items-start gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
                <Type className="text-white w-3 h-3" />
              </div>
              <span className="font-bold tracking-tight">WordFlow</span>
            </div>
            <p className="text-sm text-slate-500 text-center md:text-left">
              Advanced writing tools for modern content creators.<br />
              No tracking. No signup. Just good tools.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-8 text-sm font-medium text-slate-500">
             <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
             <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
             <a href="mailto:support@wordflow.net" className="hover:text-primary transition-colors">Contact</a>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400 uppercase tracking-widest">
            <Code className="w-4 h-4" />
            <span>Built for the Modern Web</span>
          </div>
        </div>
        <div className="text-center mt-12 text-xs text-slate-400">
          &copy; {new Date().getFullYear()} WordFlow. All rights reserved. 
        </div>
      </footer>
    </div>
  );
}
