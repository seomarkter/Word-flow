/**
 * Core text processing utilities for WordFlow
 */

export const getWordCount = (text: string): number => {
  const trimmedText = text.trim();
  if (!trimmedText) return 0;
  return trimmedText.split(/\s+/).length;
};

export const getCharCount = (text: string, includeSpaces: boolean = true): number => {
  if (includeSpaces) return text.length;
  return text.replace(/\s/g, '').length;
};

export const getSentenceCount = (text: string): number => {
  const trimmedText = text.trim();
  if (!trimmedText) return 0;
  // This is a basic regex for sentences. It can be complex, but for a tool like this, common punctuation suffices.
  return (trimmedText.match(/[.!?]+(?:[\s"']|$)/g) || []).length || (trimmedText ? 1 : 0);
};

export const getParagraphCount = (text: string): number => {
  const trimmedText = text.trim();
  if (!trimmedText) return 0;
  return trimmedText.split(/\n+/).filter(p => p.trim().length > 0).length;
};

export const getReadingTime = (wordCount: number): string => {
  if (wordCount === 0) return "0m 0s";
  const speed = 238; // As requested in formula
  const seconds = Math.max(1, Math.round((wordCount / speed) * 60));
  return seconds < 60 ? `0m ${seconds}s` : `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
};

export const getSpeakingTime = (wordCount: number): string => {
  if (wordCount === 0) return "0m 0s";
  const speed = 130; // Standard speaking speed
  const seconds = Math.max(1, Math.round((wordCount / speed) * 60));
  return seconds < 60 ? `0m ${seconds}s` : `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
};

export const getUniqueWordsCount = (text: string): number => {
  const trimmedText = text.trim().toLowerCase();
  if (!trimmedText) return 0;
  const words = trimmedText.split(/\W+/).filter(w => w.length > 0);
  return new Set(words).size;
};

export const getAverageWordLength = (text: string): number => {
  const trimmedText = text.trim();
  if (!trimmedText) return 0;
  const words = trimmedText.split(/\s+/).filter(w => w.length > 0);
  if (words.length === 0) return 0;
  const totalChars = words.reduce((acc, word) => acc + word.length, 0);
  return parseFloat((totalChars / words.length).toFixed(1));
};

export const getKeywordDensity = (text: string) => {
  const wordCount = getWordCount(text);
  if (wordCount < 20) return [];

  const stopWords = new Set([
    'we', 'our', 'us', 'i', 'me', 'my', 'you', 'your', 'he', 'she', 'it', 'they', 'them',
    'his', 'her', 'its', 'this', 'that', 'these', 'those', 'is', 'are', 'was', 'were',
    'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
    'could', 'should', 'may', 'might', 'shall', 'can', 'like', 'just', 'also',
    'more', 'very', 'so', 'but', 'and', 'or', 'the', 'a', 'an', 'of', 'in', 'on', 'at',
    'to', 'for', 'with', 'by', 'from', 'about', 'as', 'not', 'all', 'one', 'when',
    'what', 'how', 'there', 'here', 'up', 'out', 'if', 'than', 'then', 'time'
  ]);

  const words = text.toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(w => w.length > 1 && !stopWords.has(w));

  const counts: Record<string, number> = {};
  words.forEach(word => {
    counts[word] = (counts[word] || 0) + 1;
  });

  const totalFilteredWords = words.length;
  
  return Object.entries(counts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10)
    .map(([word, count]) => ({
      word,
      count,
      percentage: totalFilteredWords > 0 ? parseFloat(((count / totalFilteredWords) * 100).toFixed(1)) : 0
    }));
};

/**
 * Flesch Reading Ease Formula:
 * 206.835 - 1.015 * (total words / total sentences) - 84.6 * (total syllables / total words)
 */
export const calculateReadability = (text: string) => {
  const words = text.trim().split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;
  if (wordCount < 10) return { score: 0, level: 'Pending', grade: 'None' };

  const sentences = getSentenceCount(text) || 1;
  
  // Syllable counting is tricky in JS without a library, but we can use a basic heuristic.
  const countSyllables = (word: string) => {
    word = word.toLowerCase().replace(/[^a-z]/g, '');
    if (word.length <= 3) return 1;
    word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '');
    word = word.replace(/^y/, '');
    const syllables = word.match(/[aeiouy]{1,2}/g);
    return syllables ? syllables.length : 1;
  };

  const totalSyllables = words.reduce((acc, word) => acc + countSyllables(word), 0);

  const score = 206.835 - 1.015 * (wordCount / sentences) - 84.6 * (totalSyllables / wordCount);
  const roundedScore = Math.max(0, Math.min(100, Math.round(score)));

  let level = '';
  let grade = '';

  if (roundedScore > 90) { level = 'Easy'; grade = '5th Grade'; }
  else if (roundedScore > 80) { level = 'Easy'; grade = '6th Grade'; }
  else if (roundedScore > 70) { level = 'Easy'; grade = '7th Grade'; }
  else if (roundedScore > 60) { level = 'Medium'; grade = '8th & 9th Grade'; }
  else if (roundedScore > 50) { level = 'Medium'; grade = '10th-12th Grade'; }
  else if (roundedScore > 30) { level = 'Hard'; grade = 'College'; }
  else { level = 'Hard'; grade = 'College Graduate'; }

  return { score: roundedScore, level, grade };
};
